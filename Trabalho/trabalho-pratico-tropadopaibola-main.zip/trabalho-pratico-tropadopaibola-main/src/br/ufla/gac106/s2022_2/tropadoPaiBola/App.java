package br.ufla.gac106.s2022_2.tropadoPaiBola;
public class App {

    public static void main(String[] args) {
        Principal programa = new Principal();
        programa.menu();
    }
}
