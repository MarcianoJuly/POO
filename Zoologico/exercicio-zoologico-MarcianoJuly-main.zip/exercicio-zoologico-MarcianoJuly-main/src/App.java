public class App {
    public static void main(String[] args) throws Exception {
        InterfaceUsuario iu = new InterfaceUsuario();
        iu.executar();
    }
}
