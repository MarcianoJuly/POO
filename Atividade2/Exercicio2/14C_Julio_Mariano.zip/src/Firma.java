public class Firma{
    public static void main(String[] args) throws Exception {
        Principal passo = new Principal();
        passo.exibirMenu();
    }
}